<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\OrderApiController;

/*
|--------------------------------------------------------------------------
| API Routes - Saung Liwet System
|--------------------------------------------------------------------------
*/

// Endpoint publik untuk Pelanggan (QR Code)
Route::get('/order/meja/{id_meja}', [OrderApiController::class, 'getMenuByMeja']);
Route::post('/order/checkout', [OrderApiController::class, 'checkout']);
Route::get('/order/status/{kode_pesanan}', [OrderApiController::class, 'checkStatus']);