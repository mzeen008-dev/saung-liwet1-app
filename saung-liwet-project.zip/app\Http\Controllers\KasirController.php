<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pesanan; // Sesuaikan dengan nama model Pesanan kamu

class KasirController extends Controller
{
    // Function index untuk menampilkan pesanan di Kasir
    public function index()
    {
        $pesanan = Pesanan::all(); 

        return view('kasir.index', compact('pesanan'));
    }

    public function verifikasi($id_pesanan)
    {
        // Logic verifikasi pembayaran kasir
    }
}