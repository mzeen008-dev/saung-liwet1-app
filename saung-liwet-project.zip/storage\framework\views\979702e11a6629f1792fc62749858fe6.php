<!DOCTYPE html>
<html lang="id">
<head><meta charset="UTF-8"><title>Dashboard</title></head>
<body style="font-family: Arial; padding: 24px;">
    <h1>Login berhasil, <?php echo e(auth()->user()->nama); ?></h1>
    <form action="/logout" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit">Logout</button>
    </form>
</body>
</html><?php /**PATH C:\Users\mzeen\saung-liwet1-app\resources\views/dashboard.blade.php ENDPATH**/ ?>