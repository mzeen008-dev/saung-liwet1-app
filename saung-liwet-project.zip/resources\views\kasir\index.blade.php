<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kasir - Saung Liwet</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-4">

<div class="container">
    <h3 class="fw-bold mb-4">Kasir - Verifikasi Pesanan & Pembayaran</h3>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Kode</th>
                        <th>Meja</th>
                        <th>Pelanggan</th>
                        <th>Total</th>
                        <th>Metode</th>
                        <th>Status Bayar</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($pesanan as $p)
                    <tr>
                        <td><strong>{{ $p->kode_pesanan }}</strong></td>
                        <td>{{ $p->no_meja }}</td>
                        <td>{{ $p->nama_pelanggan }}</td>
                        <td>Rp {{ number_format($p->total_bayar, 0, ',', '.') }}</td>
                        <td><span class="badge bg-info text-dark">{{ strtoupper($p->metode_pembayaran) }}</span></td>
                        <td>
                            <span class="badge bg-{{ $p->status_pembayaran == 'lunas' ? 'success' : 'warning' }}">
                                {{ $p->status_pembayaran }}
                            </span>
                        </td>
                        <td>
                            @if($p->status_pembayaran == 'pending')
                            <form action="{{ route('kasir.verifikasi', $p->id_pesanan) }}" method="POST">
                                @csrf
                                <button type="submit" class="btn btn-sm btn-success">Verifikasi Lunas</button>
                            </form>
                            @else
                            <button class="btn btn-sm btn-secondary" disabled>Selesai</button>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">Belum ada pesanan masuk.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>