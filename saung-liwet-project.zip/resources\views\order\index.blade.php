<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesan - Meja {{ $meja->nomor_meja }}</title>
    <style>
        body { font-family: Arial, sans-serif; background: #fff3e0; margin: 0; padding: 20px; }
        h1 { text-align: center; margin-bottom: 4px; }
        .sub { text-align: center; color: #666; margin-bottom: 24px; }
        h2 { border-bottom: 2px solid #c0392b; padding-bottom: 4px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; margin-bottom: 24px; }
        .card { background: #fff; padding: 16px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,.1); }
        .card h3 { margin: 0 0 6px; }
        .card p { margin: 4px 0; font-size: 14px; color: #555; }
        .harga { font-weight: bold; color: #c0392b; font-size: 16px; }
        .habis { color: #b71c1c; font-weight: bold; }
    </style>
</head>
<body>
    <h1>Saung Liwet</h1>
    <div class="sub">Meja {{ $meja->nomor_meja }}</div>

    @if ($menus->isEmpty())
        <p style="text-align:center">Belum ada menu.</p>
    @else
        @foreach ($menus->groupBy('kategori') as $kategori => $items)
            <h2>{{ $kategori }}</h2>
            <div class="grid">
                @foreach ($items as $menu)
                    <div class="card">
                        <h3>{{ $menu->nama_menu }}</h3>
                        <p>{{ $menu->deskripsi }}</p>
                        <p class="harga">Rp {{ number_format($menu->harga, 0, ',', '.') }}</p>
                        @if ($menu->stok > 0)
                            <p>Stok: {{ $menu->stok }}</p>
                        @else
                            <p class="habis">Habis</p>
                        @endif
                    </div>
                @endforeach
            </div>
        @endforeach
    @endif
</body>
</html>