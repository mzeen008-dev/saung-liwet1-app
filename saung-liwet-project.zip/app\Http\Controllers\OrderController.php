<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Menu;
use App\Models\Meja;

class OrderController extends Controller
{
    public function index($id_meja)
    {
        $menus = Menu::all();
        $meja = Meja::findOrFail($id_meja);

        return view('order.index', compact('menus', 'meja', 'id_meja'));
    }

    public function store(Request $request)
    {
        // Proses simpan pesanan (belum diisi)
    }
}