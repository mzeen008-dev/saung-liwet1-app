<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Saung Liwet</title>
    <style>
        body { font-family: Arial, sans-serif; background: #fff3e0; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .card { background: #fff; padding: 32px; border-radius: 12px; width: 100%; max-width: 360px; box-shadow: 0 4px 16px rgba(0,0,0,.1); }
        h2 { text-align: center; margin-top: 0; }
        label { display: block; margin: 12px 0 4px; font-size: 14px; }
        input { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 6px; box-sizing: border-box; }
        button { width: 100%; margin-top: 20px; padding: 10px; background: #c0392b; color: #fff; border: 0; border-radius: 6px; font-weight: bold; cursor: pointer; }
        .error { background: #fdecea; color: #b71c1c; padding: 8px; border-radius: 6px; font-size: 13px; margin-bottom: 8px; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Login Saung Liwet</h2>
        <?php if($errors->any()): ?>
            <div class="error"><?php echo e($errors->first()); ?></div>
        <?php endif; ?>
        <form action="/login" method="POST">
            <?php echo csrf_field(); ?>
            <label>Username</label>
            <input type="text" name="username" value="<?php echo e(old('username')); ?>" required autofocus>
            <label>Password</label>
            <input type="password" name="password" required>
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html><?php /**PATH C:\Users\mzeen\saung-liwet1-app\resources\views/auth/login.blade.php ENDPATH**/ ?>