<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kasir - Saung Liwet</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-4">

<div class="container">
    <h3 class="fw-bold mb-4">Kasir - Verifikasi Pesanan & Pembayaran</h3>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Kode</th>
                        <th>Meja</th>
                        <th>Pelanggan</th>
                        <th>Total</th>
                        <th>Metode</th>
                        <th>Status Bayar</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><strong><?php echo e($p->kode_pesanan); ?></strong></td>
                        <td><?php echo e($p->no_meja); ?></td>
                        <td><?php echo e($p->nama_pelanggan); ?></td>
                        <td>Rp <?php echo e(number_format($p->total_bayar, 0, ',', '.')); ?></td>
                        <td><span class="badge bg-info text-dark"><?php echo e(strtoupper($p->metode_pembayaran)); ?></span></td>
                        <td>
                            <span class="badge bg-<?php echo e($p->status_pembayaran == 'lunas' ? 'success' : 'warning'); ?>">
                                <?php echo e($p->status_pembayaran); ?>

                            </span>
                        </td>
                        <td>
                            <?php if($p->status_pembayaran == 'pending'): ?>
                            <form action="<?php echo e(route('kasir.verifikasi', $p->id_pesanan)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-success">Verifikasi Lunas</button>
                            </form>
                            <?php else: ?>
                            <button class="btn btn-sm btn-secondary" disabled>Selesai</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">Belum ada pesanan masuk.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html><?php /**PATH C:\Users\mzeen\saung-liwet1-app\resources\views/kasir/index.blade.php ENDPATH**/ ?>