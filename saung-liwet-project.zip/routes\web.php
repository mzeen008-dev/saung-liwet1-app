<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\KasirController;
use App\Http\Controllers\KokiController;
use App\Http\Controllers\AuthController;

// 1. HALAMAN UTAMA & PELANGGAN (publik)
Route::get('/', function () {
    return redirect()->route('order.index', ['id_meja' => 1]);
});

Route::get('/order/{id_meja}', [OrderController::class, 'index'])->name('order.index');
Route::post('/order/checkout', [OrderController::class, 'store'])->name('order.checkout');

// 2. LOGIN (hanya untuk yang belum login)
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
});

Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

// 3. KASIR & DAPUR (harus login)
Route::middleware('auth')->group(function () {
    Route::get('/dashboard', fn () => view('dashboard'))->name('dashboard');

    Route::get('/kasir/pesanan', [KasirController::class, 'index'])->name('kasir.index');
    Route::post('/kasir/verifikasi/{id_pesanan}', [KasirController::class, 'verifikasi'])->name('kasir.verifikasi');

    Route::get('/koki/dapur', [KokiController::class, 'index'])->name('koki.index');
    Route::patch('/koki/update-status/{id_pesanan}', [KokiController::class, 'updateStatus'])->name('koki.updateStatus');
});