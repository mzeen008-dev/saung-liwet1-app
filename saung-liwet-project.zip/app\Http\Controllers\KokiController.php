<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pesanan; // Sesuaikan dengan nama model Pesanan kamu

class KokiController extends Controller
{
    // Function index untuk menampilkan daftar pesanan di Dapur
    public function index()
    {
        // Menampilkan pesanan yang sudah diverifikasi/dikirim ke dapur
        $pesanans = Pesanan::where('status', 'diproses')->get(); 

        return view('koki.dapur', compact('pesanans'));
    }

    public function updateStatus(Request $request, $id_pesanan)
    {
        // Logic update status masak
    }
}